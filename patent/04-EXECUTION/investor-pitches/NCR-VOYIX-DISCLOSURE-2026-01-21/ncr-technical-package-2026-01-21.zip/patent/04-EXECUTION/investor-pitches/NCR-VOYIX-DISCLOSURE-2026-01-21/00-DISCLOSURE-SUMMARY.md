# Disclosure Summary: Personal Side Project

**Date:** January 21, 2026
**From:** Bojan Janjatovic
**To:** [VP Name], NCR Voyix
**Re:** Transparency about personal project

---

## Why I'm Sharing This

You've known my work for 5 years at NCR. I want to be completely transparent about a side project I've been developing on personal time. This isn't a pitch or an ask—it's simply full disclosure because I believe in operating with transparency.

**My question at the end:** Do we need any additional non-compete agreement or similar arrangement?

---

## The Short Version

- **Project:** Elektrokombinacija - modular EV charging infrastructure for electric bus fleets
- **Company:** Netherlands BV, my wife Marija is CEO (100% dedicated)
- **My role:** CTO - technical architecture, now in oversight mode
- **Development status:** ~95% complete (kernel, HALs, test systems all working)
- **What remains:** Business-side activities (Marija handles all of it)

---

## My NCR Commitment

**100% focus on NCR continues unchanged.**

Let me be direct:
- I'm not leaving NCR
- I'm not reducing my commitment
- The technical development work is essentially done
- What remains is business development, which Marija handles full-time

The engineering work happens on evenings and weekends—my personal time. It doesn't interfere with my NCR responsibilities.

---

## Current Status

**Development phase is complete:**
- Real-time kernel (EK-KOR2) - working
- Hardware abstraction layers - working
- Test systems - comprehensive coverage
- Technical documentation - complete

**Business phase is Marija's domain:**
- Investor conversations
- Partnership discussions
- Regulatory compliance
- Operations planning

I provide technical oversight when needed, but this is advisory, not development work.

---

## Weekend Research Collaboration

I have research collaborations with two advisors—one PhD-level distributed systems expert (official), one infrastructure veteran (informal childhood friend). Important context:

- **Timing:** Weekends only (suits all our work schedules)
- **Nature:** Academic research, algorithm formalization
- **Pace:** Slow, no deadlines, no production pressure
- **Purpose:** Potential academic publications, not commercial development

Details on both advisors are in the accompanying document (02-ADVISOR-COLLABORATION.md).

---

## How This Benefits NCR

Working with these advisors brings knowledge back to NCR—at no cost to the company:

| Source | What I Learn | NCR Benefit |
|--------|--------------|-------------|
| **PhD distributed systems advisor** | Consensus algorithms, formal methods | Better architecture decisions |
| **Bell Labs-trained infrastructure advisor** | Engineering discipline from 911 systems | Reliability-first mindset |
| **17 years mission-critical experience** | Patterns that survive production | Fewer costly mistakes |
| **Critical Azure infrastructure insights** | Hyperscale operations perspective | Cloud operations knowledge |

My infrastructure advisor friend can't participate formally—his employer prohibits it. But he *can* share decades of hard-won experience privately: lessons learned, patterns that work, mistakes to avoid. No proprietary details, just wisdom from building systems where failure means people don't get help when they call 911.

**This is knowledge that would cost a fortune through formal consulting. NCR gets it for free through my improved engineering judgment.**

**The kernel and operating system will be open source.** Knowledge flows freely—nothing locked away.

---

## What I'm Asking

**Do we need any additional non-compete agreement or similar arrangement between me and NCR Voyix regarding this project?**

I'm genuinely asking for guidance here. If NCR's legal or compliance team wants additional protections, I'm happy to discuss reasonable arrangements. My goal is to be completely above-board about this.

---

## Materials Included

This package contains:

1. **01-PROJECT-OVERVIEW.md** - What the project actually is
2. **02-ADVISOR-COLLABORATION.md** - Details on external collaborators
3. **03-SESSION-UPDATE-2026-01-21.md** - Example of weekend research work
4. **ncr-technical-package-2026-01-21.zip** - Full source code (for complete transparency)
5. **README.md** - Package navigation

I'm providing full technical materials because I have nothing to hide. This is a side project in a completely different domain (EV infrastructure) from NCR's business (retail and banking technology).

---

## Contact

I'm happy to discuss any of this in person. Just let me know what questions you have.

Bojan Janjatovic
bojan.janjatovic@gmail.com

---

*This disclosure is provided in confidence to NCR Voyix management.*
