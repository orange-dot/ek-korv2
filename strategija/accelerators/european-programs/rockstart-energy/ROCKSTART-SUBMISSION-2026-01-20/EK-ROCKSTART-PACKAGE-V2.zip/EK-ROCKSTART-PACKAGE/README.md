# Elektrokombinacija Technical Package

**Prepared for:** Infineon Technologies
**Date:** 2026-01-20
**Contact:** Bojan Janjatović <bojan.janjatovic@gmail.com>

## Overview

Elektrokombinacija is developing modular EV charging infrastructure for electric bus fleets. This package contains our TC397XP emulator and distributed RTOS implementation, demonstrating our capability to develop sophisticated embedded systems targeting Infineon's AURIX platform.

## Contents

### 1. tcpxxx-emulator/

Functional emulator for TC397XP (TriCore TC1.6.2P architecture).

**Capabilities:**
- ~150 TriCore instructions implemented
- CSA (Context Save Area) emulation with linked list management
- Boots RTOS firmware to idle loop
- GDB remote debugging framework (in progress)
- Multi-core simulation support (single core active)

**Status:** Core instruction set functional, passes RTOS boot tests.

### 2. ek-kor2/

**EK-KOR2** - Distributed RTOS for modular power electronics coordination.

**Key Features:**
- Potential field scheduling (no central scheduler)
- Topological k=7 neighbor coordination
- Threshold consensus for distributed voting
- Adaptive execution bands with backpressure
- Hardware fault tolerance through neighbor voting

**Implementations:**
- `c/` - C implementation (POSIX, FreeRTOS, bare-metal targets)
- `rust/` - Rust implementation (no_std compatible)
- `renode/` - Renode simulation configurations

### 3. pre-hw-dev-tricore/

Test firmware for TC397XP emulator validation.

**Contains:**
- Minimal RTOS kernel startup
- CSA initialization routines
- TriCore-specific startup code
- CMake build configuration for HighTec toolchain

### 4. docs/

Selected technical documentation:
- `00-system-architecture.md` - System architecture philosophy
- `02-roj-intelligence.md` - ROJ distributed swarm algorithms
- `07-v2g-control.md` - V2G control system design
- `ek-kor-rtos-technical-report.md` - Complete RTOS design document

## Building

### TC397XP Emulator

```bash
cd tcpxxx-emulator
mkdir build && cd build
cmake ..
cmake --build .

# Run tests
./tcpxxx-test
```

**Requirements:** CMake 3.16+, C++17 compiler (GCC, Clang, MSVC)

### EK-KOR2 (POSIX simulation)

```bash
cd ek-kor2/c
mkdir build && cd build
cmake .. -DEKK_PLATFORM=posix
make

# Run demo
./ek_kor2_demo
```

**Requirements:** CMake 3.16+, C11 compiler

### EK-KOR2 (Rust)

```bash
cd ek-kor2/rust
cargo build --release
cargo test
```

**Requirements:** Rust 1.70+

### Test Firmware (requires HighTec toolchain)

```bash
cd pre-hw-dev-tricore
./build-firmware.sh
```

**Requirements:** HighTec TriCore toolchain

## Architecture Highlights

### Distributed RTOS (EK-KOR2)

The RTOS uses physics-inspired "potential field" scheduling where tasks are attracted to execution slots based on:
- Urgency (deadline proximity)
- Resource availability
- Neighbor coordination signals

This eliminates central scheduler bottlenecks and enables graceful degradation when modules fail.

### TC397XP Emulator

The emulator was developed to enable pre-hardware development and testing. It implements:
- Full TC1.6.2P instruction decoding
- Memory-mapped peripheral stubs
- CSA context switching (function calls, interrupts)
- Cycle-approximate timing

## Technical Contact

For questions about this package:
- **Email:** bojan.janjatovic@gmail.com
- **Subject line:** "Infineon Technical Package - [Topic]"

## License

- **Source code:** MIT License
- **Documentation:** Proprietary - For Infineon evaluation only
